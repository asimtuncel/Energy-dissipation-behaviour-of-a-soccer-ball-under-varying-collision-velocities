# -*- coding: utf-8 -*-
"""



"""


import numpy as np
import matplotlib.pyplot as plt
import statistics
name='4'
ball_name='4'
cap=22.28


name1=name+'_1'
name2=name+'_2'
name3=name+'_3'
name4=name+'_4'
name5=name+'_5'


file=open(name+'_mean_comp_FORCE.txt','w')
file2=open(name+'_mean_res_FORCE.txt','w')


x_path1=name1
x_path2=name2
x_path3=name3
x_path4=name4
x_path5=name5




data1=np.genfromtxt(x_path1+'_impact_force.txt',delimiter=' ',usecols=(2))
data2=np.genfromtxt(x_path2+'_impact_force.txt',delimiter=' ',usecols=(2))
data3=np.genfromtxt(x_path3+'_impact_force.txt',delimiter=' ',usecols=(2))
data4=np.genfromtxt(x_path4+'_impact_force.txt',delimiter=' ',usecols=(2))
data5=np.genfromtxt(x_path5+'_impact_force.txt',delimiter=' ',usecols=(2))




cor1=[]
cor2=[]
cor3=[]
cor4=[]
cor5=[]

time11=[]
time12=[]
time13=[]
time14=[]
time15=[]


cor_comp=[]
cor_res=[]
dev_comp=[]
dev_rest=[]
for i in range(0,len(data1)):   
    cor1.append((data1[i]))  
    norm11=((i+1-1)/(len(data1)-1))/2
    time11.append(norm11)      
for i in range(0,len(data2)):
    cor2.append((data2[i]))
    norm12=((i+1-1)/(len(data2)-1))/2
    time12.append(norm12)  
for i in range(0,len(data3)):
    cor3.append((data3[i]))
    norm13=((i+1-1)/(len(data3)-1))/2
    time13.append(norm13)  
for i in range(0,len(data4)):
    cor4.append((data4[i]))
    norm14=((i+1-1)/(len(data4)-1))/2
    time14.append(norm14)  
for i in range(0,len(data5)):
    cor5.append((data5[i])) 
    norm15=((i+1-1)/(len(data5)-1))/2
    time15.append(norm15)  

b=40
time_bası=[]
for g in range(0,40):
    norm111=((g+1-1)/(40-1))
    time_bası.append(norm111*100)

    c1=cor1[int(round((len(cor1)/b)*(g),0))]
    c2=cor2[int(round((len(cor2)/b)*(g),0))]
    c3=cor3[int(round((len(cor3)/b)*(g),0))]
    c4=cor4[int(round((len(cor4)/b)*(g),0))]
    c5=cor5[int(round((len(cor5)/b)*(g),0))]


        
    v=(c1,c2,c3,c4,c5)
  
    cor_mean=statistics.mean(v)
    
    dev=statistics.stdev(v)
    cor_comp.append(cor_mean)
    dev_comp.append(dev)


cor2_1=[]
cor2_2=[]
cor2_3=[]
cor2_4=[]
cor2_5=[]


time21=[]
time22=[]
time23=[]
time24=[]
time25=[]


plt.plot(time_bası,cor_comp,'k-',linewidth=2,label='Compression Phase')
#plt.plot(time_top,cor_res,'k--',linewidth=2, label='Restitution Phase')
plt.grid(':')
plt.ylim(0,3800)
plt.ylabel('Joule',fontsize=14)
plt.xlabel('Time [%]',fontsize=12)
plt.legend(['Compression Phase','Restitution Phase'])
plt.legend()


for i in range(0,len(cor_comp)):
    file.write(str(time_bası[i])+' '+str(cor_comp[i])+' '+str(dev_comp[i])+'\n')


file.close()

plt.show()
