# -*- coding: utf-8 -*-
"""



"""

import numpy as np
import matplotlib.pyplot as plt

ball_name='6_'

fig,(ax,ax2) = plt.subplots(1, 2, sharey=True)

data1=np.genfromtxt(ball_name+'1_WORK_CP.txt',delimiter=' ',usecols=(0,1))
data2=np.genfromtxt(ball_name+'1_WORK_RP.txt',delimiter=' ',usecols=(0,1))
data3=np.genfromtxt(ball_name+'2_Work_CP.txt',delimiter=' ',usecols=(0,1))
data4=np.genfromtxt(ball_name+'2_Work_RP.txt',delimiter=' ',usecols=(0,1))
data5=np.genfromtxt(ball_name+'3_Work_CP.txt',delimiter=' ',usecols=(0,1))
data6=np.genfromtxt(ball_name+'3_Work_RP.txt',delimiter=' ',usecols=(0,1))
data7=np.genfromtxt(ball_name+'4_Work_CP.txt',delimiter=' ',usecols=(0,1))
data8=np.genfromtxt(ball_name+'4_Work_RP.txt',delimiter=' ',usecols=(0,1))
data9=np.genfromtxt(ball_name+'5_Work_CP.txt',delimiter=' ',usecols=(0,1))
data10=np.genfromtxt(ball_name+'5_Work_RP.txt',delimiter=' ',usecols=(0,1))
data11=np.genfromtxt(ball_name+'mean_comp_Work.txt',delimiter=' ',usecols=(0,1))
data12=np.genfromtxt(ball_name+'mean_res_Work.txt',delimiter=' ',usecols=(0,1))

x1=data1[:,0]*100
x2=sorted(data2[:,0]*100,reverse=True)
x3=data3[:,0]*100
x4=sorted(data4[:,0]*100,reverse=True)
x5=data5[:,0]*100
x6=sorted(data6[:,0]*100,reverse=True)
x7=data7[:,0]*100
x8=sorted(data8[:,0]*100,reverse=True)
x9=data9[:,0]*100
x10=sorted(data10[:,0]*100,reverse=True)
x11=data11[:,0]
x12=data12[:,0]
rest1=sorted(x12,reverse=True)


y1=(data1[:,1])
y2=sorted(data2[:,1],reverse=True)
y3=data3[:,1]
y4=sorted(data4[:,1],reverse=True)
y5=data5[:,1]
y6=sorted(data6[:,1],reverse=True)
y7=data7[:,1]
y8=sorted(data8[:,1],reverse=True)
y9=data9[:,1]
y10=sorted(data10[:,1],reverse=True)
y11=data11[:,1]
y12=data12[:,1]
rest=sorted(y12,reverse=True)


# plot the same data on both axes
ax.plot(x1, y1, 'gray')
ax2.plot(x2, y2, 'gray',label='Throws')
ax.plot(x3, y3, 'gray')
ax2.plot(x4, y4, 'gray')
ax.plot(x5, y5, 'gray')
ax2.plot(x6, y6, 'gray')
ax.plot(x7, y7, 'gray')
ax2.plot(x8, y8, 'gray')
ax.plot(x9, y9, 'gray')
ax2.plot(x10, y10, 'gray')
ax.plot(x11, y11, 'k--',linewidth=3,label='mean')
ax2.plot(x12, rest, 'k--',linewidth=3,label='mean')

ax.grid(':')
ax2.grid(':')

# zoom-in / limit the view to different portions of the data

ax.set_title("Compression Phase")
ax2.set_title("Restitution Phase")
ax.set_xlabel('Time [%]')
ax2.set_xlabel('Time [%]')
ax.set_ylabel('Work [Joule]')
ax2.set_ylabel(' ')
ax.set_ylim(0,25000)
ax2.set_ylim(0,25000)
ax2.set_xlim(100,0)
ax.set_xlim(0,100)
# hide the spines between ax and ax2
ax.spines['right'].set_visible(False)
ax2.spines['left'].set_visible(False)
ax.yaxis.tick_left()
#ax.tick_params(labeltop='off') # don't put tick labels at the top
ax2.yaxis.tick_right()
ax2.legend()
# Make the spacing between the two axes a bit smaller
plt.subplots_adjust(wspace=0)

plt.show()