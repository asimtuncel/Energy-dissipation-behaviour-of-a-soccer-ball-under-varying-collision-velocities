# -*- coding: utf-8 -*-
"""



"""


import numpy as np
import matplotlib.pyplot as plt
import statistics
name='4'
ball_name='4'
cap=22.28


name1=name+'_1'
name2=name+'_2'
name3=name+'_3'
name4=name+'_4'
name5=name+'_5'


file=open(name+'_mean_comp_EPE.txt','w')
file2=open(name+'_mean_res_EPE.txt','w')


x_path1='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name1
x_path2='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name2
x_path3='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name3
x_path4='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name4
x_path5='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name5


x_path11='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name1
x_path21='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name2
x_path31='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name3
x_path41='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name4
x_path51='C:\\Users\\LEO\\Desktop\\HIZA_GÖRE_EDDC\\tekrar\\'+name5


data1=np.genfromtxt(x_path1+'_EPE_CP.txt',delimiter=' ',usecols=(1))
data2=np.genfromtxt(x_path2+'_EPE_CP.txt',delimiter=' ',usecols=(1))
data3=np.genfromtxt(x_path3+'_EPE_CP.txt',delimiter=' ',usecols=(1))
data4=np.genfromtxt(x_path4+'_EPE_CP.txt',delimiter=' ',usecols=(1))
data5=np.genfromtxt(x_path5+'_EPE_CP.txt',delimiter=' ',usecols=(1))


data2_1=np.genfromtxt(x_path1+'_EPE_RP.txt',delimiter=' ',usecols=(1))
data2_2=np.genfromtxt(x_path2+'_EPE_RP.txt',delimiter=' ',usecols=(1))
data2_3=np.genfromtxt(x_path3+'_EPE_RP.txt',delimiter=' ',usecols=(1))
data2_4=np.genfromtxt(x_path4+'_EPE_RP.txt',delimiter=' ',usecols=(1))
data2_5=np.genfromtxt(x_path5+'_EPE_RP.txt',delimiter=' ',usecols=(1))


cor1=[]
cor2=[]
cor3=[]
cor4=[]
cor5=[]

time11=[]
time12=[]
time13=[]
time14=[]
time15=[]


cor_comp=[]
cor_res=[]
dev_comp=[]
dev_rest=[]
for i in range(0,len(data1)):   
    cor1.append((data1[i]))  
    norm11=((i+1-1)/(len(data1)-1))/2
    time11.append(norm11)      
for i in range(0,len(data2)):
    cor2.append((data2[i]))
    norm12=((i+1-1)/(len(data2)-1))/2
    time12.append(norm12)  
for i in range(0,len(data3)):
    cor3.append((data3[i]))
    norm13=((i+1-1)/(len(data3)-1))/2
    time13.append(norm13)  
for i in range(0,len(data4)):
    cor4.append((data4[i]))
    norm14=((i+1-1)/(len(data4)-1))/2
    time14.append(norm14)  
for i in range(0,len(data5)):
    cor5.append((data5[i])) 
    norm15=((i+1-1)/(len(data5)-1))/2
    time15.append(norm15)  

b=20
time_bası=[]
for g in range(0,20):
    norm111=((g+1-1)/(20-1))
    time_bası.append(norm111*100)

    c1=cor1[int(round((len(cor1)/b)*(g),0))]
    c2=cor2[int(round((len(cor2)/b)*(g),0))]
    c3=cor3[int(round((len(cor3)/b)*(g),0))]
    c4=cor4[int(round((len(cor4)/b)*(g),0))]
    c5=cor5[int(round((len(cor5)/b)*(g),0))]


        
    v=(c1,c2,c3,c4,c5)
  
    cor_mean=statistics.mean(v)
    
    dev=statistics.stdev(v)
    cor_comp.append(cor_mean)
    dev_comp.append(dev)


cor2_1=[]
cor2_2=[]
cor2_3=[]
cor2_4=[]
cor2_5=[]


time21=[]
time22=[]
time23=[]
time24=[]
time25=[]


for i in range(0,len(data2_1)):   
    cor2_1.append((data2_1[i]))  
    norm1=((i+1-1)/(len(data2_1)-1))/2
    time21.append(norm1)  
time21.reverse()       
for i in range(0,len(data2_2)):
    cor2_2.append((data2_2[i]))
    norm2=((i+1-1)/(len(data2_2)-1))/2
    time22.append(norm2)  
time22.reverse()  
for i in range(0,len(data2_3)):
    cor2_3.append((data2_3[i]))
    norm3=((i+1-1)/(len(data2_3)-1))/2
    time23.append(norm3)  
time23.reverse() 
for i in range(0,len(data2_4)):
    cor2_4.append((data2_4[i]))
    norm4=((i+1-1)/(len(data2_4)-1))/2
    time24.append(norm4)  
time24.reverse() 
for i in range(0,len(data2_5)):
    cor2_5.append((data2_5[i])) 
    norm5=((i+1-1)/(len(data2_5)-1))/2
    time25.append(norm5)  
time25.reverse()  
    

 
b=20
time_top=[]
for g in range(0,20):
    
    norm11=((g+1-1)/(20-1))
    time_top.append(norm11*100)

    c2_1=cor2_1[int(round((len(cor2_1)/b)*(g),0))]
    c2_2=cor2_2[int(round((len(cor2_2)/b)*(g),0))]
    c2_3=cor2_3[int(round((len(cor2_3)/b)*(g),0))]
    c2_4=cor2_4[int(round((len(cor2_4)/b)*(g),0))]
    c2_5=cor2_5[int(round((len(cor2_5)/b)*(g),0))]


        
    v2=(c2_1,c2_2,c2_3,c2_4,c2_5)
  
    cor_mean_res=statistics.mean(v2)
    
    dev_res=statistics.stdev(v2)
    cor_res.append(cor_mean_res)
    dev_rest.append(dev_res)
time_top.reverse()

plt.plot(time_bası,cor_comp,'k-',linewidth=2,label='Compression Phase')
plt.plot(time_top,cor_res,'k--',linewidth=2, label='Restitution Phase')
plt.grid(':')
plt.ylim(0,3800)
plt.ylabel('Joule',fontsize=14)
plt.xlabel('Time [%]',fontsize=12)
plt.legend(['Compression Phase','Restitution Phase'])
plt.legend()

# İF SHIW GRAPH REMOVE QUOTATION MARKS

'''  
plt.plot(time11,cor1,'k-',linewidth=3)
plt.plot(time21,cor2_1,'k--',linewidth=3)
plt.plot(time12,cor2,'y-',linewidth=3)
plt.plot(time22,cor2_2,'y--',linewidth=3)
plt.plot(time13,cor3,'b-',linewidth=3)
plt.plot(time23,cor2_3,'b--',linewidth=3)
plt.plot(time14,cor4,'g-',linewidth=3)
plt.plot(time24,cor2_4,'g--',linewidth=3)
plt.plot(time15,cor5,'m-',linewidth=3)
plt.plot(time25,cor2_5,'m--',linewidth=3)
plt.plot(time16,cor6,'c-',linewidth=3)
plt.plot(time26,cor2_6,'c--',linewidth=3)
plt.plot(time17,cor7,'k-',linewidth=3)
plt.plot(time27,cor2_7,'k--',linewidth=3)
plt.plot(time18,cor8,'k-',linewidth=3)
plt.plot(time28,cor2_8,'k--',linewidth=3)
plt.plot(time19,cor9,'k-',linewidth=3)
plt.plot(time29,cor2_9,'k--',linewidth=3)
'''


for i in range(0,len(cor_comp)):
    file.write(str(time_bası[i])+' '+str(cor_comp[i])+' '+str(dev_comp[i])+'\n')

for i in range(0,len(cor_res)):
    file2.write(str(time_top[i])+' '+str(cor_res[i])+' '+str(dev_rest[i])+'\n')
file.close()
file2.close()
plt.show()
