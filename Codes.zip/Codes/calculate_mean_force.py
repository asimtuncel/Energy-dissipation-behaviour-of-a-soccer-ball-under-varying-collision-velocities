# -*- coding: utf-8 -*-
"""


"""

import numpy as np
import matplotlib.pyplot as plt
import statistics


# parameters

NAME = "5"               # Ball name / experiment ID
N_TRIALS = 5             # Number of trials
BINS = 40                # Number of bins for averaging
OUTPUT_FILE = f"{NAME}_mean_comp_FORCE.txt"


def load_trial_data(name: str, trial: int, column: int = 2) -> np.ndarray:

    path = f"{name}_{trial}_impact_force.txt"
    return np.genfromtxt(path, delimiter=" ", usecols=(column,))


# Collect all trials into a list
trial_data = [load_trial_data(NAME, i) for i in range(1, N_TRIALS + 1)]


def compute_mean_std(data_list, bins=40):

    time_axis = np.linspace(0, 100, bins)
    mean_vals, std_vals = [], []

    for g in range(bins):
        # pick value at proportional index for each trial
        values = [
            d[int(round(len(d) / bins * g, 0))] for d in data_list
        ]
        mean_vals.append(statistics.mean(values))
        std_vals.append(statistics.stdev(values))

    return time_axis, mean_vals, std_vals


time_axis, mean_comp, std_comp = compute_mean_std(trial_data, BINS)


with open(OUTPUT_FILE, "w") as f:
    for t, m, s in zip(time_axis, mean_comp, std_comp):
        f.write(f"{t} {m} {s}\n")

plt.plot(time_axis, mean_comp, "k-", linewidth=2, label="Compression Phase")


plt.fill_between(
    time_axis,
    np.array(mean_comp) - np.array(std_comp),
    np.array(mean_comp) + np.array(std_comp),
    color="gray",
    alpha=0.3,
    label="±1 std"
)

plt.grid(":")
plt.ylim(0, 3800)
plt.ylabel("Force [N]", fontsize=14)
plt.xlabel("Time [%]", fontsize=12)
plt.legend()
plt.show()
