# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 18:24:58 2025

@author: LEO
"""

import numpy as np
import matplotlib.pyplot as plt
import statistics

# variables
name = '4'
CAP = 22.28
BINS = 20
files = [f"{name}_{i}" for i in range(1, 6)]


def load_data(prefix, suffix, usecol=0):

    path = f"{prefix}{suffix}"

    try:
        data = np.genfromtxt(path, delimiter=' ', usecols=(usecol))
        if data.size == 0:
            raise ValueError(f"Empty or invalid data in {path}")
        return data
    except Exception as e:
        print(f"Error loading {path}: {e}")
        return np.zeros(20)  # veya raise e


def calc_mean_stdev(datasets, bins=20):
    """Calculate mean and standard deviation for multiple datasets."""
    results_mean, results_std = [], []
    for g in range(bins):
        values = [data[int(round((len(data) / bins) * g, 0))]
                  for data in datasets]
        results_mean.append(statistics.mean(values))
        results_std.append(statistics.stdev(values))
    return results_mean, results_std


def process_girinti(data_list, cap, bins=20):
    """Prepare indentation (girinti) ratio data and ensure length = bins."""
    gir_data = []
    max_val = max(data_list)

    before, after = [], []
    i = 0
    for i in range(len(data_list)):
        if data_list[i] != 0 and data_list[i] == max_val:
            break
        if data_list[i] != 0:
            before.append(data_list[i])
    for j in range(i + 1, len(data_list)):
        if data_list[j] != 0:
            after.append(data_list[j])

    for g in range(bins):
        values = [arr[int(round((len(arr)/bins)*g, 0))]
                  for arr in [before]]
        gir_data.append(statistics.mean(values)/cap*100)

    while len(gir_data) < bins:
        gir_data.append(gir_data[-1])
    return before, after, gir_data


compr_datasets = [load_data(f, '_cor_compr_phase.txt') for f in files]

res_datasets = [load_data(f, '_cor_res_phase.txt') for f in files]

metrik_datasets = [load_data(f, '_metrik_hesap.txt', usecol=3) for f in files]

cor_comp, dev_comp = calc_mean_stdev(compr_datasets, BINS)
cor_res, dev_res = calc_mean_stdev(res_datasets, BINS)

all_gir_com, all_gir_res = [], []
for data in metrik_datasets:
    before, after, gir_com = process_girinti(data, CAP, BINS)
    all_gir_com.append(gir_com)
    all_gir_res.append(after)

gir_data_com = [statistics.mean(vals) for vals in zip(*all_gir_com)]
gir_data_res = [statistics.mean(vals) for vals in zip(*all_gir_com)]

with open(f"{name}_mean_comp_cor.txt", 'w') as f1, \
     open(f"{name}_mean_res_cor.txt", 'w') as f2, \
     open(f"{name}_mean_cor_gir.txt", 'w') as f3:

    for i in range(len(cor_comp)):
        line_com = f"{cor_comp[i]} {dev_comp[i]} {gir_data_com[i]}\n"
        f1.write(line_com)
        f3.write(line_com)

    for i in range(len(cor_res)):
        line_res = f"{cor_res[i]} {dev_res[i]} {gir_data_res[i]}\n"
        f2.write(line_res)
        f3.write(line_res)

plt.plot(gir_data_com, cor_comp, 'k', label='Compression')
plt.plot(gir_data_res, cor_res, 'r', label='Restitution')
plt.legend(fontsize=10)
plt.grid(':')
plt.ylim(0.5, 1.1)
plt.xlim(0, 0.2)
plt.ylabel('COR', fontsize=12)
plt.xlabel('Indentation ratio', fontsize=12)
plt.title('Mean COR')
plt.show()
