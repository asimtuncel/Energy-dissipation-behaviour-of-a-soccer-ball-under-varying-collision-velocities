# -*- coding: utf-8 -*-


import numpy as np 
import matplotlib.pyplot as plt
import statistics



ball_name = '4_1'
trial1 = '_impact_force.txt'
trial2 = '_metrik_hesap.txt'
trial3 = '_spring_damper.txt'
trial4 = '_area.txt'
cap = 0.2228


value = 0 #extends the line to get force values ​​up to the maximum indentation (visual control on hysteresis graph)
start = 0#start CP
stop = 0 #Tstop RP

x_path1 = ball_name + trial1
x_path2 = ball_name + trial2
x_path3 = ball_name + trial3
x_path4 = ball_name + trial4


data = np.genfromtxt(x_path1, delimiter = " ", usecols = (0,1,2))
data2 = np.genfromtxt(x_path2, delimiter = " ", usecols = (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14))
data3 = np.genfromtxt(x_path3, delimiter = " ", usecols = (0,1))
data4 = np.genfromtxt(x_path4, delimiter = " ", usecols = (0))


x1 = np.genfromtxt(x_path1, delimiter = " ", usecols = (0,1,2))
x2 = np.genfromtxt(x_path2, delimiter = " ", usecols = (0,1))
x3 = np.genfromtxt(x_path3, delimiter = " ", usecols = (0,1))
x4 = np.genfromtxt(x_path4, delimiter = " ", usecols = (0))

file = open(ball_name + '_cor_compr_phase.txt', 'w')
file2 = open(ball_name + '_cor_res_phase.txt', 'w')

#%% 
''' Determines the line numbers for the initial contact moment, the maximum deformation moment, and the finishing moment'''
y = data[:,2]
f = max(y)

num = 0
for i in range(0, len(data)):
    if data[i][2] < f:
        num = num + 1
    else:
        break
num1 = 0
for i in range(0, len(data2)):
    if data2[i][3] != 0:
        break
    else:
        num1 = num1 + 1

#%%
'''Creates a list of force values ​​from the moment of first contact to maximum indentation'''
'''Creates a list of force values ​​from the maximum deformation until the recovery phase ends.'''
up = [] #Comparision Phase (CP)
down = [] #restitution phase (RP)
value11 = []
value22 = []
norm1 = []
norm2 = []
area_up = []
area_down = []

#read of force and area 
for i in range(start, num + value):
    up.append(data[i][2])
 
    area_up.append(data4[i])
    
for i in range(num + value, len(data) - (start + stop)):    
    down.append(data[i - 1][2])

    area_down.append(data4[i])
    
 #normalize of time
for i in range(1,len(up) + 1):
    norm_1 = (i - 1)/((len(up)) - 1) 
    norm1.append(norm_1)    
    
  
down.append(data[start][2])  #For the intersection of the lines, the final value of the recovery phase was set as the initial value of the compression phase

for i in range(1, len(down) + 1):
    norm_2 = (i - 1) / ((len(down)) - 1) 
    norm2.append(norm_2)  
#%%%
'''Since the hysteresis graph is formed according to deformation, the section that creates the indentaiton values ​​in 
two different lists as compression and recovery phases.'''
x_axis1=[] #indentation values of CP
x_axis2=[] #indentation values of RP

for i in range(num1 + start, num1 + start + len(up)): #start stop determination
    x_axis1.append((data2[i][3] / cap) * 100)
     
    
for i in range(num1 + len(up) + start, num1 + len(up) + len(down) + start - 1):
    x_axis2.append((data2[i - 1][3] / cap) * 100) 
    
x_axis2.append((data2[num1 + start][3] / cap) * 100) 
area_down.append(data4[0])  #first momnet of CP and last moment of RP

#%%
'''The x,y positions of both lines (compression, indentation) are given'''
      
new_y1 = np.array([norm1, up, x_axis1, area_up])    #create CP values (respectively; indentation, force, indentation ratio, area)
new_y2 = np.array([norm2, down, x_axis2, area_down])  #create RP values (respectively; indentation, force, indentation ratio, area)


#%%%
'''To draw a hysteresis graph, create the x,y coordinates of the new line determined to bring the compression phase
 to the intersection or maximum indentation.'''
new_data_x = [] #indentation data
new_data_y = [] #force data

for i in range(0, len(up)):
    new_data_x.append((new_y1[2][i] / cap) * 100)
    new_data_y.append(new_y1[1][i])
    
for i in range(0, len(down)):
    new_data_x.append((new_y2[2][i] / cap) * 100)  
    new_data_y.append(new_y2[1][i])    


#%%%
'''trapezidual calculation to determine to area that under the line'''
#below the line with only the trapezoid function  ''' this code creates for Stronge formula'''
results1 = np.trapz(new_y1[1])  #CP
results2 = np.trapz(new_y2[1])  #RP
area = (results1 + results2 - results1) / results1#calculate area
##cumulative calculation to work below the lines
from scipy import integrate
up_cum_trapz = []
down_cum_trapz = []
y_int = integrate.cumtrapz(new_y1[1], initial=0)
for i in range(0, len(y_int)):
    up_cum_trapz.append(y_int[i])
results11 = up_cum_trapz[i]
y_int2 = integrate.cumtrapz(new_y2[1], initial=0)
for i in range(0, len(y_int2)):
    down_cum_trapz.append(y_int2[i])

results22 = -1*down_cum_trapz[i] #make positive in order to calculation of COR
#%%
'''Hysteresis Graph'''
import hysteresis as h

cor_up = []
cor_down = []
fig = plt.figure()
ax1 = fig.add_subplot(111)

ax = plt.twinx()
cor_up.append(1)

enerji_bası = open(ball_name + '_EPE_CP.txt', 'w')
work_bası = open(ball_name + '_WORK_CP.txt', 'w')
for i in range(1, len(up_cum_trapz)):
    A = new_y1[3][i]
    L = (new_y1[2][i] * cap ) / 100
    k = (up_cum_trapz[i] / (L))

    eddc = (k * cap) / A
    cor_eddc = 1-(up_cum_trapz[i] / eddc) * 100
    EPE = (eddc * A * L**2) / (2 * cap**2) #elactic potential energy

    enerji_bası.write(str(new_y1[0][i]) + ' ' + str(EPE) + '\n')
    work_bası.write(str(new_y1[0][i]) + ' '+str(up_cum_trapz[i]) + '\n')

    cor_up.append(cor_eddc)
   
x_cor_axis = []
cor_force_22 = []
ym_2 = []

enerji_top = open(ball_name + '_EPE_RP.txt', 'w')
work_top = open(ball_name + '_WORK_RP.txt', 'w')
for i in range(1, len(down_cum_trapz)):
    A2 = new_y2[3][i]
    L2 = (new_y2[2][i] * cap) / 100
    x_cor_axis.append((new_y2[2][i]))
    k2 = (down_cum_trapz[len(down_cum_trapz) - i] / (L2))
    eddc2 = (k2 * cap) / A2
    EPE2 = (eddc2 * A2 * L2**2) / (2 * cap**2)
    
    cor_eddc2 = 1-(down_cum_trapz[len(down_cum_trapz) - i] / eddc2) * 100
  
    enerji_top.write(str(new_y2[0][i]) + ' '+str(EPE2) + '\n')
    work_top.write(str(new_y2[0][i]) + ' '+str(down_cum_trapz[i]) + '\n')
    cor_down.append(cor_eddc2)
cor_down.append(1)  
x_cor_axis.append((0)) 
    

ax.plot(x_axis1, cor_up, 'bo-', label = "COR Comprasion Phase")
ax.plot(x_cor_axis, cor_down, 'go-', label = "COR Restitution Phase")
'''A plot was created to visually examine the intersections of lines'''
ax1.plot(x_axis1, up,'ks-', label = "CP")
ax1.plot(x_axis2, down, 'rs-', label = "RP")
ax1.set_xlim(0, 25)
ax1.set_ylim(-0.200, 4500)
ax.set_ylim(0.5, 1.05)

ax1.grid(':', color='gray')

ax.invert_yaxis()
ax.set_title('Coefficient of Restitituion Graph During Collision\nAccording to Phases '+ball_name+'.Trial')
ax1.legend(loc = 'upper left')
ax.legend(loc = 'upper right')
ax1.set_ylabel("Force [N]")
ax1.set_xlabel("Indentation Ratio [%]")

ax.tick_params(axis ='y', labelcolor ='b')
ax.set_ylabel('COR [AU]', color = 'b')

fig, ax = plt.subplots()

x = new_data_x
y = new_data_y
xy = np.column_stack([x,y])
hız_h = h.Hysteresis(xy)
hız_h.plot(showReversals = True,color='k')


#ax.plot(x_axis1,cor_up,'bo-',label="Coefficient of Restitution")
plt.ylabel("Newton [N]")
plt.xlabel("Percentage [%]")

plt.show()
#%%

 #restitution phase
area = ((results1 + results2) - results1) / results1#area
print('CP Work:', results11) #CF
print('RP work:', results22) #RF
print('Total Work:', results1 + results2)
print('Stronge Formula', area**0.5) 


a = statistics.mean(cor_up)
b = statistics.mean(cor_down)

print('mean EDDC of CP', a)
print('mean EDDC of RP', b)
print('total EDDC of collision', (a + b) / 2) #to compare with Stronge



#%%
for i in range(0, len(cor_up)):
    file.write(str(cor_up[i]) + "\n")
for i in range(0, len(cor_down)):
    file2.write(str(cor_down[i]) + "\n")
file.close()
file2.close()
enerji_bası.close()
enerji_top.close()
work_bası.close()
work_top.close()