# -*- coding: utf-8 -*-

import os
import numpy as np
import cv2
import matplotlib.pyplot as plt

images = []
folder = ("Please write your falder path")  # folder path
name = "4.1_digi.txt"

for subdir, dirs, files in os.walk(folder):
    for file in files:
        if ".jpg" in file:
            frame = cv2.imread(os.path.join(subdir, file))
            if frame is not None:
                images.append(frame)
num_of_file = np.zeros((len(images), 3))
for k, img in enumerate(images):
    # blurred image
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    rows = 512
    blurred = cv2.medianBlur(gray, 3)
    # ball parameters
    minDist = 50
    param1 = 40
    param2 = 20
    minRadius = 125  # minumum diametrer
    maxRadius = 135  # maximum diameter
    # deetect circle
    circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT,
                               0.01, 512, minDist,
                               param1=param1, param2=param2,
                               minRadius=minRadius,
                               maxRadius=maxRadius)

    if circles is not None:
        circles = np.uint16(np.around(circles))

        for i in circles[0, :]:
            cv2.circle(img, (i[0], i[1]), i[2], (0, 500, 0), 3)
            cv2.circle(img, (i[0], i[1]), 2, (0, 0, 255), 3)
            center = (i[0], i[1], i[2])
            print(i[2])
            num_of_file[k, :] = np.asarray(center)
            with open(name, "a") as output:
                output.write(str(i[0])+" "+str(i[1])+"\n")
    # Show results
    cv2.imshow('img', img)
    cv2.imshow('gry', blurred)
    cv2.waitKey(80)
    cv2.destroyAllWindows()

plt.axis('Equal')
plt.grid(True)
plt.show()
