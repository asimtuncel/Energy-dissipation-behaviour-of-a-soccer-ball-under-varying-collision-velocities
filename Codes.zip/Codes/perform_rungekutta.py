# -*- coding: utf-8 -*-
import numpy as np
from scipy.integrate import solve_ivp
import math
import matplotlib.pyplot as plt
from matplotlib.offsetbox import AnchoredText
from sklearn.metrics import mean_squared_error
# Change folder name to calculate data

ball = '4_1'   # Change the name

ball_weigth = 0.436
cap = 0.1114

data_name_hesap = ball+"_metrik_hesap.txt"
data_vel = ball+'_velocity.txt'
data_acc = ball+'_acceleration.txt'
data_force = ball+'_force.txt'
data_impact_force = ball+'_impact_force.txt'
spring_damp = ball+'_spring_damper.txt'

data = np.genfromtxt(data_name_hesap, delimiter=" ",
                     usecols=(0, 1, 2, 3, 4, 5, 6,
                              7, 8, 9, 10, 11, 12, 13, 14))

'''calculate ball mass during collision'''

ball_volume = (4*3.14*cap**2)

ball_mass = []
ball_mass2 = []

for i in range(0, len(data)):
    a_h = (data[i][7]/2)

    ball_v = (3.14*(a_h**2+((data[i][3])**2)))

    ball_mass.append(ball_weigth-(ball_v*ball_weigth)/ball_volume)
    if a_h != 0:
        ball_mass2.append((ball_weigth-(ball_v*ball_weigth)/ball_volume))

''' # to detect impact moment and impact moment row '''
r = len(data)
num = 1

for i in range(0, r-1):
    if data[i][3] != 0:
        break
    else:
        num = num+1
num2 = 0
for i in range(0, r-1):
    if data[i][3] != 0:
        num2 = num2+1
        deformation = (data[:, 3])
time = 1
def_max = max(deformation)

for i in range(num-1, num+num2+1, 1):
    if data[i][3] == def_max:
        break
    else:
        time = time+1

time_impact = time*1/4000

'''##Runga Kutta'''

data_values = np.genfromtxt(spring_damp, delimiter=' ', usecols=(0, 1))

stime = data_values[0][1]  # time [s]
m = ball_weigth  # mass [kg]

k = data_values[3][1]  # spring stiffness [N/m]
v0 = data_values[5][1]  # initial velocity [m/s]

g = 9.806  # gravity [m/sË2]
dt = 0.00025  # time step [s]
n = int(round(stime/dt))
tspan = (np.linspace(0.0, stime, n))


'''# ODE function'''


def MassSpring(t, state, m, k, g):

    c = (2*(k*m)**0.5)
    x = state[0]
    g = 9.8
    xd = state[1]

    F = -k*x-(c*(x*t))-m*g
    xdd = F/m  # xdd = ((k*x)/m) â g # return the two state derivatives
    return [xd, xdd]


sol = solve_ivp(MassSpring, [tspan[0], tspan[-1]],
                [0, v0], method="RK45",
                t_eval=tspan, args=(m, k, g))

'''Check model and experiment results with Root Mean Square Error (RMSE)'''
data_rk = open(ball+'_runga_kutta_outputs.txt', 'w')
data = np.genfromtxt(data_name_hesap, delimiter=" ",
                     usecols=(0, 1, 2, 3, 4, 5, 6, 7,
                              8, 9, 10, 11, 12, 13, 14))
file_of_deformation = np.zeros((time, 2))
file_of_velocity = np.zeros((time, 2))
data_velocity = np.genfromtxt(data_vel, delimiter=' ', usecols=(0, 1, 2))
'''loop to collect data (deformation and velocity)'''

for z in range(0, time, 1):
    deformation_rk = (data[(z-2)+num][3])
    velocity_rk = (data_velocity[(z-2)+num][0])
    model_x = sol.y[0][z]*100
    model_y = sol.y[1][z]*100

    file_of_deformation[z][0] = np.asarray(deformation_rk)*100
    file_of_deformation[z][1] = np.asarray(model_x)
    file_of_velocity[z][0] = np.asarray(velocity_rk)*-1
    file_of_velocity[z][1] = np.asarray(model_y)/100

for i in range(0, len(sol.y[1])):
    data_rk.write(str(sol.y[0][i]*100) + ' ' +
                  str(file_of_deformation[i][1]) + ' ' +
                  str(sol.y[1][i]) + ' ' +
                  str(file_of_velocity[i][1]) + '\n')
data_rk.close()
rmse_calc = np.genfromtxt(ball+'_runga_kutta_outputs.txt', delimiter=' ',
                          usecols=(0, 1))

RMSE_girinti = mean_squared_error(file_of_deformation[:, 0],
                                  file_of_deformation[:, 1], squared=False)
RMSE_hız = mean_squared_error(file_of_velocity[:, 0],
                              file_of_velocity[:, 1],
                              squared=False)
deformation_dif = max(file_of_deformation[:, 0])-min(file_of_deformation[:, 0])
velocity_dif = max(file_of_velocity[:, 0])-min(file_of_velocity[:, 0])

print(RMSE_girinti)
print(RMSE_hız)

perc_rk = ((RMSE_girinti)/deformation_dif)*100
perc_vel = (RMSE_hız/velocity_dif)*100
print(perc_rk)
print(perc_vel)

fig, ax = plt.subplots()
ax1 = ax.twinx()
ax.tick_params(axis='y', colors='blue')

ax1.plot(sol.t, file_of_deformation[:, 0], '-+k')
ax1.plot(sol.t, file_of_deformation[:, 1], '--r')
ax.plot(sol.t, file_of_velocity[:, 0], '-+b')
ax.plot(sol.t, file_of_velocity[:, 1], '--g')

ax.set_xlabel('t [s]')
ax1.set_ylabel('Centimeter [cm]', color='k')
ax.set_ylabel('Velocity [m/s]', color='k')

ax.legend(['Velocity Exp.', 'Velocity Model'],
          bbox_to_anchor=(0.25, 1), loc=1, borderaxespad=0., fontsize=8)
ax1.legend(['Indentation Exp.', 'Indentation Model'],
           bbox_to_anchor=(1, 1), loc=1, borderaxespad=0., fontsize=8)
ax.set_ylim([-0.5, 16])
ax1.set_ylim([0, 5])

ax.grid()
plt.show()
data_rk.close()
