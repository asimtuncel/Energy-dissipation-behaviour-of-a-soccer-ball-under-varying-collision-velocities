# -*- coding: utf-8 -*-
"""



"""

# -*- coding: utf-8 -*-
"""


"""
import numpy as np

def calculate_affine(I, S, method = 1):
    """     Affine Coordinate Transformation                       
    I : Image Coordinates of Calibration Points
    S : Space Coordinates of Calibration Points
    method : 1. LSM, 2. Psedou Inverse 
     
    returns calibration coefficients """

    rS, cS = S.shape
    rI, cI = I.shape
    # check the matrix dimensions
    if cS > 3 or cI > 2:
        raise ValueError ('Error in Matrix Dimensions')
    
    u = I[:,0]     # Image coordiantes of calibration frame x values
    v = I[:,1]      # Image coordiantes of calibration frame y values
      
    # Coefficients Matrix
    A1 = np.column_stack((u, v, np.ones(rI), np.zeros((rI,3))))
    A2 = np.column_stack((np.zeros((rI,3)), u, v, np.ones(rI)))
    A = np.vstack((A1, A2))
    # Right hand side of the equation
    b = np.reshape(S, -1, 'F') # Fortran Style
 
    # To solve Ax = b there are two approaches
    # 1. linear least squares 
    # 2. pseudoinverse  
    if method == 1:
        L = (np.linalg.lstsq(A, b, rcond=None))[0]
    elif method == 2:
        L = np.dot(np.linalg.pinv(A), b)
    else:
        print("Missing method : use (1) for Least Squares use (2) for Pseudoinverse")
        L = []
    return L

def calculate_reaffine(x, I):
    """ Reconstruction of 2D Positions
        Image Coordinates of Marker Points : I
        Affine Coefficients           : x """

    rI, cI = I.shape
    
    u = I[:,0] # Image coordiantes of markers x values
    v = I[:,1] # Image coordiantes of markers y values
      
    # Coefficients Matrix
    A1 = np.column_stack((u, v, np.ones(rI), np.zeros((rI,3))))
    A2 = np.column_stack((np.zeros((rI,3)), u, v, np.ones(rI)))
    A = np.vstack((A1, A2))
    H = A@x
    
    return H.reshape(int(len(H)/2), 2, order='F')


def calc_velocity(H, dt):
    vx = [(x2-x1)/(2*dt) for x1, x2 in zip(H[:-3,0], H[2:,0])]
    vy = [(y2-y1)/(2*dt) for y1, y2 in zip(H[:-3,1], H[2:,1])]
    
    return np.asarray([vx, vy]).T
    

if __name__ == '__main__':
    # main program
    # Calibration frame world coordinates in cm
    S = np.array([[0.03, 0.023],         # 1. 
                  [0.03, 0.175],         # 3.
                  [0.03, 0.40],         # 4.
                  [0.03, 0.53],         # 5.
                  [0.37, 0.57],         # 6.
                  [0.37, 0.355],         # 8.
                  [0.37, 0.265],         # 9.
                  [0.37, 0.084]])        # 10.
    
  #  [0.03 0.023;0.03 0.175;0.03 0.40;0.03 0.53;0.37 0.084;0.37 0.265;0.37 0.355;0.37 0.57]
    
    # load digitized calibration image coordinates
    I = np.loadtxt('calib_im.txt')     
    # apply conformal mapping
    x = calculate_affine(I, S, 1)
    #%% print conformal calibration values
    # Rotation of the measurement system
    theta = np.rad2deg(np.arctan(-x[1]/x[4]))
    t = np.rad2deg(np.arctan(x[3]/x[0]))
    # Nonorthogonality of the measurement axes
    alpha = theta + t
    
    scaleX = x[0]*(np.cos(alpha)/np.cos(t))
    scaleY = x[4]*(np.cos(alpha)/np.cos(t))
    
    
    #%% load experiment 2D data
    ad = '6_5'
    ad_2 = ad+"throw"
    data_name_hesap = ad + "_metrik_hesap.txt"
    ball_drop = np.loadtxt(ad + '_filtre.txt', delimiter=' ')
    metric_data = open(ad + '_metrik.txt','w')
    H = calculate_reaffine(x, ball_drop)
    length=len(H)
    
    
    for i in range(0,length):
        
        metric_data.write(str(H[i][0]) + ' ' + str(H[i][1]) + '\n')
        
    metric_data.close()
    #%% plot results
    import matplotlib.pyplot as plt
    
    fig = plt.figure(figsize = (15, 5)) # a figure with a single Axes

    ax1 = fig.add_subplot(131)
    ax2 = fig.add_subplot(132)
    ax3 = fig.add_subplot(133)
   
    ax1.scatter(H[:,0], H[:,1], color='k', s=25, alpha=0.5, label=ad_2+' Displacement')
    ax1.set_title(ad+'.'+' Graph for Trial\n')
    ax1.set_xlabel('X [cm]',fontsize=11)
    ax1.set_ylabel('Y [cm]',fontsize=11)
    ax1.legend()
    ax1.axis('equal')
    ax1.grid(True, linestyle=':')
    

    
    frameRate = 4000
    V = calc_velocity(H, 1/frameRate) # velocity
    A = calc_velocity(V, 1/frameRate) # acceleration
   # print(A)
    v_time = []
    a_time = []
    for i in range(0, len(V)):
        v_time.append((i + 1) * 0.00025)
    for j in range(0, len(A)):
        a_time.append((j + 1) * 0.00025)
       

    ax2.plot(v_time, V[:,0], color='grey', linewidth = 4, label = 'Hrizontal Velocity')
    ax2.plot(v_time, V[:,1], 'k', linewidth = 4,label = 'Vertical Velocity')
   
    ax2.set_ylim([-20, 20])
    ax2.set_xlim([0, len(v_time) * 1/6000])
    #ax2.set_title(ad+'.'+' Deneme Hız Grafiği\n')
    ax2.set_xlabel('Time [sn]', fontsize=11)
    ax2.set_ylabel('Velocity [$ms^-$$^1$]', fontsize=11)  
    ax2.grid(True, linestyle = ':')
    ax2.legend()
 
    

    ax3.plot(a_time, A[:,0] / 100.0, 'grey', linewidth = 4,label = 'Horizontal Acceleration')
    ax3.plot(a_time, A[:,1] / 100.0, 'k', linewidth = 4, label = 'Vertical Acceleration')
   
 
    ax3.set_ylim([-5000, 10000])
    ax3.set_xlabel('Time [sn]', fontsize=11)
    ax3.set_ylabel('Acceleration [$ms^-$$^2$]', fontsize=11)
    ax3.grid(True, linestyle = ':')
    ax3.legend()
    
    