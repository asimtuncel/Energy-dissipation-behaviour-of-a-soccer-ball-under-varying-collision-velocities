# -*- coding: utf-8 -*-
"""



"""

import numpy as np
import math
import matplotlib.pyplot as plt

ball="7_5"

data = np.genfromtxt(ball + "_metrik.txt", delimiter=" ", usecols=(0,1))

a = len(data)
wall = 0.000245303590348355 #fixed x position of the wall (calculation point determined by visual inspection - first contact moment frame position)
save_calc = open(ball + "_metrik_hesap.txt", "w")
for i in range(0,a):
    r_x = data[i][0]  # x position of geometric center of the ball
    r_y = (data[i][1]) # y position of geometric center of the ball

    cap = 0.1114
    edge = (data[i][0])-cap #edge of the ball
    
    if edge > wall: 
        edge = edge
        rx_up = r_x       #fixed x position of the wall - for upper partial of the ball
        rx_down = r_x     #fixed x position of the wall - for lower partial of the ball
        indentation = 0   #Finding the indentation with the edge position of the bal
        y_boy = math.sqrt(abs((((wall-(r_x))**2)-(cap**2)))) #two equal-sided right triangles with respect to the length in the indentation and the length of the side halfway from the hypotenuse
        y_up = r_y        #Adding the found side length for the y position inside the top of the ball
        y_down = r_y        #Adding the found side length for the y-position at the bottom of the ball
       #calculate ange
        a = 0
        b = 0
        c = 0
        deg = 0 #impact angle of the ball in each moment
        
        impact_sphere = 0  #circumference of the ball
        impact_area = 0
        save_calc.write(str(r_x) + " " + str(r_y) + " " + str(edge) + " " + str(indentation) + " "+str(y_boy) + " " + str(y_up) + " " + 
                        str(y_down) + " "+str(a) + " "+str(b) + " " + str(c) + " " + str(deg) + " " + str(impact_sphere) + " " + str(impact_area) +
                        " " + str(rx_up) + " " + str(rx_down) + "\n")
    else:
        rx_up=wall #Dfixed x position of the wall - for upper partial of the ball
        rx_down = wall #fixed x position of the wall - for lower partial of the ball
        indentation = abs((data[i][0]-cap)-wall)#Finding the indentation with the edge position of the bal
        y_boy = math.sqrt(abs((((wall-r_x)**2)-(cap**2))))#two equal-sided right triangles with respect to the length in the indentation and the length of the side halfway from the hypotenuse
        y_up = r_y+y_boy #Adding the found side length for the y position inside the top of the ball
        y_down = r_y-y_boy #Adding the found side length for the y-position at the bottom of the ball
       #calculate ange
        a = math.sqrt((rx_up-rx_down)**2+(y_up-y_down)**2)
        b = math.sqrt((rx_up-r_x)**2+(y_up-r_y)**2)
        c = math.sqrt((r_x-rx_down)**2+(r_y-y_down)**2)
        deg = math.degrees(math.acos(((b**2+c**2-a**2)/(2*b*c)))) #impact angle of the ball in each moment
        
        pi_say = 3.14
      
        impact_area = ((pi_say*(a/2)**2)) #area for each moment
        impact_sphere = deg*((2*cap*pi_say)/360) #circumference of the ball (for impact surface)

       
        
        save_calc.write(str(r_x) + " " + str(r_y) + " " + str(edge) + " " + str(indentation) + " "+str(y_boy) + " " + str(y_up) + " " + 
                        str(y_down) + " "+str(a) + " "+str(b) + " " + str(c) + " " + str(deg) + " " + str(impact_sphere) + " " + str(impact_area) +
                        " " + str(rx_up) + " " + str(rx_down) + "\n")
    
save_calc.close()

    
    