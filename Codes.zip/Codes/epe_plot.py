# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 17:28:31 2025

@author: LEO
"""

import numpy as np
import matplotlib.pyplot as plt

# variables
BALL_NAME = "4_"
N_TRIALS = 4  # trial value

# set figure
fig, (ax, ax2) = plt.subplots(1, 2, sharey=True)
#%%

# Read and plot
for i in range(1, N_TRIALS + 1):
    # Commpression Phase
    data_cp = np.genfromtxt(f"{BALL_NAME}{i}_EPE_CP.txt", delimiter=" ", usecols=(0, 1))
    x_cp = data_cp[:, 0] * 100
    y_cp = data_cp[:, 1]
    ax.plot(x_cp, y_cp, "gray")

    # RP dosyası (Restitution Phase)
    data_rp = np.genfromtxt(f"{BALL_NAME}{i}_EPE_RP.txt", delimiter=" ", usecols=(0, 1))
    x_rp = sorted(data_rp[:, 0] * 100, reverse=True)
    y_rp = sorted(data_rp[:, 1], reverse=True)
    ax2.plot(x_rp, y_rp, "gray", label="Throws" if i == 1 else None)
#%%
# read mean values
mean_cp = np.genfromtxt(f"{BALL_NAME}mean_comp_epe.txt", delimiter=" ", usecols=(0, 1))
mean_rp = np.genfromtxt(f"{BALL_NAME}mean_res_epe.txt", delimiter=" ", usecols=(0, 1))

x_mean_cp, y_mean_cp = mean_cp[:, 0], mean_cp[:, 1]
x_mean_rp, y_mean_rp = mean_rp[:, 0], mean_rp[:, 1]
y_mean_rp_sorted = sorted(y_mean_rp, reverse=True)

#%%
# plot means
ax.plot(x_mean_cp, y_mean_cp, "k--", linewidth=3, label="Mean")
ax2.plot(x_mean_rp, y_mean_rp_sorted, "k--", linewidth=3, label="Mean")

# plot setting
ax.grid(":")
ax2.grid(":")

ax.set_title("Compression Phase")
ax2.set_title("Restitution Phase")

ax.set_xlabel("Time [%]")
ax2.set_xlabel("Time [%]")

ax.set_ylabel("EPE [Joule]")
ax2.set_ylabel(" ")

ax.set_ylim(0, 4500)
ax2.set_ylim(0, 4500)

ax.set_xlim(0, 100)
ax2.set_xlim(100, 0)

# edit axes
ax.spines["right"].set_visible(False)
ax2.spines["left"].set_visible(False)
ax.yaxis.tick_left()
ax2.yaxis.tick_right()
ax2.legend()

# edit distance between two plots
plt.subplots_adjust(wspace=0)

plt.show()
