# -*- coding: utf-8 -*-
"""
Created on Sun Sep 14 17:39:59 2025

@author: LEO
"""

import numpy as np
import matplotlib.pyplot as plt
import statistics

# variables
NAME = "7"       # Ball name
N_TRIALS = 5     # Number of trials
BINS = 20        # Number of bins for averaging
CAP = 22.28      # bal diamters (cm)

#%% set and load data
file_comp = open(f"{NAME}_mean_comp_WORK.txt", "w")
file_res = open(f"{NAME}_kmean_res_WORK.txt", "w")


comp_data = [
    np.genfromtxt(f"{NAME}_{i}_WORK_CP.txt", delimiter=" ", usecols=(1))
    for i in range(1, N_TRIALS + 1)
]
res_data = [
    np.genfromtxt(f"{NAME}_{i}_WORK_RP.txt", delimiter=" ", usecols=(1))
    for i in range(1, N_TRIALS + 1)
]

#%% mean and std calculate
def compute_mean_std(data_list, bins=20, reverse=False):
    """Compute mean and std curves across trials (binned)."""
    time_axis = np.linspace(0, 100, bins)
    mean_vals, std_vals = [], []

    for g in range(bins):
        values = [
            d[int(round(len(d) / bins * g, 0))] for d in data_list
        ]
        mean_vals.append(statistics.mean(values))
        std_vals.append(statistics.stdev(values))

    if reverse:
        time_axis = list(reversed(time_axis))
    return time_axis, mean_vals, std_vals

# Compression phase
time_comp, mean_comp, std_comp = compute_mean_std(comp_data, BINS, reverse=False)

# Restitution phase (reverse time axis)
time_res, mean_res, std_res = compute_mean_std(res_data, BINS, reverse=True)

#%%save results
for t, m, s in zip(time_comp, mean_comp, std_comp):
    file_comp.write(f"{t} {m} {s}\n")
for t, m, s in zip(time_res, mean_res, std_res):
    file_res.write(f"{t} {m} {s}\n")

file_comp.close()
file_res.close()

#%%plot

plt.plot(time_comp, mean_comp, "k-", linewidth=2, label="Compression Phase (mean)")
plt.plot(time_res, mean_res, "k--", linewidth=2, label="Restitution Phase (mean)")


plt.grid(":")
plt.ylim(0, 33000)
plt.xlabel("Time [%]", fontsize=12)
plt.ylabel("Work [Joule]", fontsize=14)
plt.legend()
plt.show()
