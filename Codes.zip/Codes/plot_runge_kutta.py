# -*- coding: utf-8 -*-
"""



"""

import os
import numpy as np
import matplotlib.pyplot as plt

# path
data_dir = 'C:\\Users\\LEO\Desktop\\EDDC_for_SMF'  # path of folder

# category and trials
categories = ['4', '5', '6', '7']
repeat_number = 5

# create two figre for indentation and velocity
for category in categories:
    ind_fig, ind_ax = plt.subplots()
    vel_fig, vel_ax = plt.subplots()

    # set legend for model and xperiment
    legend_model_added = False
    legend_exp_added = False

    for repeat in range(1, repeat_number + 1):
        file_name = f"{category}_{repeat}_runga_kutta_outputs.txt"
        file_path = os.path.join(data_dir, file_name)

        try:
            data = np.loadtxt(file_path)

            model_ind = data[:, 0]
            exp_ind = data[:, 1]
            model_hiz = data[:, 2]
            exp_vel = data[:, 3]

            # Normalize x axis (0-100 arası)
            x_norm = np.linspace(0, 100, len(data))

            # indentation graph
            ind_ax.plot(
                x_norm, model_ind,
                color='red', linestyle='-',
                label='Model' if not legend_model_added else None
            )
            ind_ax.plot(
                x_norm, exp_ind,
                color='black', linestyle='--',
                label='Experiment' if not legend_exp_added else None
            )

            # Graph of velocity
            vel_ax.plot(
                x_norm, model_hiz,
                color='red', linestyle='-',linewidth=1,
                label='Model' if not legend_model_added else None
            )
            vel_ax.plot(
                x_norm, exp_vel,
                color='black', linestyle='--',
                label='Experiment' if not legend_exp_added else None
            )

            # Bir kez legend etiketlerini ekledikten sonra tekrar etme
            legend_model_added = True
            legend_exp_added = True

        except Exception as e:
            print(f"Hata oluştu: {file_path} -> {e}")

    # set indentation graph labels
    ind_ax.set_title(f'{category} - Model vs Experimental Data for Indentation ')
    ind_ax.set_xlabel('Time (%)')
    ind_ax.set_ylabel('Indentation (cm)')
    ind_ax.legend()
    ind_ax.grid(True)

    # set velocity graph labels
    vel_ax.set_title(f'{category} - Model vs Experimental Data for Velocity')
    vel_ax.set_xlabel('Time (%)')
    vel_ax.set_ylabel('Velocity (m/s)')
    vel_ax.legend()
    vel_ax.grid(True)

    # save graph being figure
    ind_fig.savefig(f"{category}_indentation.png", dpi=300, bbox_inches='tight')
    vel_fig.savefig(f"{category}_velocity.png", dpi=300, bbox_inches='tight')

    plt.close(ind_fig)
    plt.close(vel_fig)

print("Done.")